# Genetic discrimination policy: integrated economic evaluation (JAX/XLA)

This repository is a reproducible scaffold for a linked, modular economic evaluation of policy options restricting genetic discrimination, implemented with a JAX-first stack.

## Contents
- `protocols/`: protocol and OSF presubmission materials
- `src/`: modelling modules and glue code
- `configs/`: YAML configuration for policies, priors, and run settings
- `scripts/`: runnable entry points (once dependencies are installed)
- `tests/`: fast unit tests for invariants and equilibrium solvers
- `outputs/`: versioned run outputs (not committed by default in real use)

## Quick start (local)
1. Create an environment (recommended: uv, conda, or venv).
2. Install dependencies listed in `pyproject.toml`.
3. Run `python -m scripts.run_policy_sweep`.

Notes:
- This scaffold assumes CPU execution by default. GPU is optional.
- JAX requires `jaxlib` appropriate to your platform.

## Reproducibility
- Deterministic seeds are mandatory.
- Policy contrasts should use common random numbers for variance reduction.
- Each run writes an immutable manifest (config + git hash + timestamp).

## License
Add the license that matches your intended use and data sharing constraints.
