from __future__ import annotations

import yaml
from pathlib import Path

import jax
import jax.numpy as jnp

from src.model.glue_policy_eval import GlobalParams
from src.model.module_a_behavior import BehaviorParams
from src.model.module_b_clinical import ClinicalParams
from src.model.module_c_insurance_eq import InsuranceParams
from src.model.glue_policy_eval import simulate_policy

def load_yaml(path: Path):
    return yaml.safe_load(path.read_text())

def main():
    cfg = load_yaml(Path("configs/base.yaml"))
    pol_cfg = load_yaml(Path("configs/policies.yaml"))
    seed = int(cfg["seed"])
    key = jax.random.PRNGKey(seed)

    # Placeholder parameters. Replace with inference outputs.
    params = GlobalParams(
        behavior=BehaviorParams(baseline_logit=-2.0, policy_shock=1.0, trend=0.01),
        clinical=ClinicalParams(
            baseline_event_rate=0.02,
            uptake_to_prevention=0.5,
            prevention_effect=0.6,
            cost_per_event=20000.0,
            qaly_loss_per_event=0.3,
        ),
        insurance=InsuranceParams(
            base_premium=1000.0,
            loss_cost=700.0,
            expense_load=0.2,
            markup=0.1,
            adverse_selection_sensitivity=0.3,
            price_elasticity=1.2,
        )
    )

    results = []
    # Use common random numbers by splitting once, then reusing per policy in the same order.
    base_key, = jax.random.split(key, 1)

    for name, rule in pol_cfg["policies"].items():
        policy = {"name": name, **rule}
        res = simulate_policy(base_key, policy, params)
        results.append(res)

    for r in results:
        print(r["policy"], "net_qalys=", float(r["net_qalys"]), "avg_premium=", float(r["avg_premium"]))

if __name__ == "__main__":
    main()
