"""
Policy glue: integrate modules and compute decision metrics

This is a scaffold. Replace placeholder models with jurisdiction-specific and data-driven implementations.

Design goals:
- Pure functions compatible with JAX transforms (jit, vmap, scan).
- Deterministic randomness via explicit PRNG keys.
- Shape-safe arrays (use jaxtyping/chex in real implementations).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, Tuple

try:
    import jax
    import jax.numpy as jnp
except Exception as e:
    raise ImportError(
        "JAX (and jaxlib) must be installed to run this module. "
        "Install platform-appropriate jaxlib and rerun."
    ) from e

from .module_a_behavior import BehaviorParams, run_module as run_behavior
from .module_b_clinical import ClinicalParams, simulate_outcomes
from .module_c_insurance_eq import InsuranceParams, run_module as run_insurance

@dataclass(frozen=True)
class GlobalParams:
    behavior: BehaviorParams
    clinical: ClinicalParams
    insurance: InsuranceParams

def simulate_policy(key: jax.Array, policy: Dict[str, Any], params: GlobalParams) -> Dict[str, Any]:
    """
    One policy simulation pass (deterministic given key and params).
    Common random numbers should be implemented by splitting keys consistently across policies.
    """
    # Module A
    out_a = run_behavior(key, policy, params.behavior, T=120)
    uptake = out_a["uptake"]

    # Module B
    out_b = simulate_outcomes(uptake, params.clinical)

    # Module C
    out_c = run_insurance(policy, params.insurance)

    # Minimal DCBA-style metric placeholders
    # Replace with full accounting: healthcare costs, premiums, fiscal spillovers, equity weights, etc.
    net_health_cost = -jnp.sum(out_b["cost_savings"])  # negative means savings
    net_qalys = jnp.sum(out_b["qaly_gains"])
    avg_premium = out_c["premium"]
    takeup = out_c["takeup"]

    return {
        "policy": policy["name"],
        "net_health_cost": net_health_cost,
        "net_qalys": net_qalys,
        "avg_premium": avg_premium,
        "insurance_takeup": takeup,
        "series": {
            "uptake": uptake,
            "prevented_events": out_b["prevented_events"],
        }
    }
