# Genetic discrimination policy: integrated economic evaluation (JAX/XLA)

This repository is a reproducible scaffold for a linked, modular economic evaluation of policy options restricting genetic discrimination, implemented with a JAX-first stack.

## Contents
- `protocols/`: protocol and OSF presubmission materials
- `src/`: modelling modules and glue code
- `configs/`: YAML configuration for policies, priors, and run settings
- `scripts/`: runnable entry points (once dependencies are installed)
- `tests/`: fast unit tests for invariants and equilibrium solvers
- `outputs/`: versioned run outputs (not committed by default in real use)

## Quick start (local)
1. Create an environment (recommended: uv, conda, or venv).
2. Install dependencies listed in `pyproject.toml`.
3. Run `python -m scripts.run_policy_sweep`.

Notes:
- This scaffold assumes CPU execution by default. GPU is optional.
- JAX requires `jaxlib` appropriate to your platform.

## Reproducibility
- Deterministic seeds are mandatory.
- Policy contrasts should use common random numbers for variance reduction.
- Each run writes an immutable manifest (config + git hash + timestamp).

## License
Add the license that matches your intended use and data sharing constraints.


## Context engineering
See `docs/CONTEXT_ENGINEERING.md` and the `context/` directory for assumption tracking, jurisdiction profiles, and experiment cards.


## VOI
Run `python -m scripts.run_voi` to compute EVPI/EVPPI on a toy net benefit definition (replace with DCBA/welfare net benefit).


## Jurisdictions
- Australia: `configs/policies_australia.yaml` (run with `--jurisdiction australia`)
- New Zealand: `configs/policies_new_zealand.yaml` (run with `--jurisdiction new_zealand`)


## Posterior conversion
- `python -m scripts.convert_posterior_csv_to_npy --csv <file.csv> --kind behavior --out outputs/posterior_samples/behavior_posterior.npy`

## Joint sampling control
`run_full_uncertainty` supports `--sampling_mode independent|common_index|random`.

## Uncertainty decomposition
- `python -m scripts.run_uncertainty_decomposition --run_dir <full_uncertainty_run_dir>`

## Build joint draws (optional)
- `python -m scripts.build_joint_draws --out outputs/posterior_samples/joint_draws.npy --n_draws 1000 --mapping ... --behavior ... --mode common_index`


## Full uncertainty from joint draws
- `python -m scripts.run_full_uncertainty_from_joint --jurisdiction australia --joint_draws outputs/posterior_samples/joint_draws.npy --n_draws 500`
See `docs/JOINT_DRAWS.md`.


## Total-order sensitivity (approx)
- `python -m scripts.run_uncertainty_decomposition_total --run_dir <full_uncertainty_run_dir>`
See `docs/TOTAL_ORDER_SENSITIVITY.md`.


## Meta pipeline (AU + NZ)
- `python -m scripts.run_meta_pipeline --n_draws 500` (see `docs/META_PIPELINE.md`)


## Publish pack
- `python -m scripts.publish_pack --meta_dir outputs/runs/meta_pipeline/<timestamp>` (see `docs/PUBLISH_PACK.md`)


## Game-theoretic framing
See `docs/GAME_THEORETIC_FRAMING.md` for the strategic interaction mapping and modelling rationale.


## Conductor workflow
This repo includes a `conductor/` directory compatible with the Conductor extension for Gemini CLI.
- Install: `gemini extensions install https://github.com/gemini-cli-extensions/conductor --auto-update`
- Project index: `conductor/index.md`
- Tracks registry: `conductor/tracks.md`
