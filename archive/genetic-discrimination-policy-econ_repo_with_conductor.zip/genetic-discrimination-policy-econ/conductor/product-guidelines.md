# Product guidelines

## Writing and documentation
- Prefer clear, concrete language; avoid jargon unless necessary.
- Treat word counts as targets when drafting publication artifacts.
- Keep section numbering sequential and cross-references consistent.
- Avoid em-dashes (use commas or parentheses only when truly needed).
- Keep “claims” paired with evidence registers (jurisdiction profiles) or explicit assumptions.

## Scientific posture
- Separate normative claims (“should”) from descriptive claims (“is”).
- When evidence is weak, represent uncertainty explicitly and elevate the gap via VOI/EVPPI.
- Prefer sensitivity-ready parameterisations over hard-coded constants.

## Repo hygiene
- Do not delete prior versions; use versioned files where appropriate.
- Keep config-driven runs under `configs/` and write outputs under `outputs/`.
- Every runnable script writes a machine-readable manifest (`run_manifest.json`).

## Output expectations
- AU/NZ comparisons should be generated from the same posterior structure when possible.
- Publish artifacts should be reproducible from a `meta_pipeline` run directory.
