# Implementation plan: Evidence anchoring and calibration (AU/NZ)

## Phase 1 — Evidence registers
- [ ] Populate Australia evidence register (Module A deterrence; Module C assumptions; proxy substitution; enforcement)
- [ ] Populate New Zealand evidence register
- [ ] Add policy timeline tables (dates, caps, enforcement mechanisms)

## Phase 2 — Calibration targets and priors
- [ ] Define calibration targets per module (uptake, premium changes, take-up, claims proxies)
- [ ] Convert evidence into prior distributions (documented in configs)
- [ ] Add sensitivity-ready parameter groupings for EVPPI

## Phase 3 — Identification plan and data access
- [ ] Write identification plan (survey linkage; admin health; insurer aggregates; event study)
- [ ] Add “data access and governance” appendix
- [ ] Update runbook with calibration workflow

## Phase 4 — Update outputs
- [ ] Update meta pipeline to include evidence tables in publish pack (optional)
- [ ] Produce a brief “evidence to priors” appendix for policy brief

