# Project Workflow

## Guiding principles
1. **The plan is the source of truth:** all work must be tracked in `conductor/tracks/<track_id>/plan.md`.
2. **Config-driven:** prefer adding/adjusting YAML configs over hard-coded constants.
3. **Reproducibility:** deterministic seeds where possible; each run writes `run_manifest.json`.
4. **Evidence anchoring:** priors/assumptions must be logged in `context/jurisdiction_profiles/*`.
5. **Tests where it matters:** prioritise unit tests for core transforms, IO boundaries, and invariants.

## Task workflow (adapted for research repos)
Status codes:
- `[ ]` not started
- `[~]` in progress
- `[x]` done

Standard flow:
1. Select next `[ ]` task in the active track’s plan.
2. Mark `[~]`.
3. Implement change.
4. Run relevant checks (tests, lint, smoke run).
5. Mark `[x]` and note key artifacts/outputs/paths.
6. Commit code changes + commit plan update.

## Minimal development commands
### Setup
```bash
python -m venv .venv
# Activate:
#   macOS/Linux: source .venv/bin/activate
#   Windows: .venv\Scripts\activate
pip install -U pip
pip install -e .
```

### Run key pipelines
```bash
python -m scripts.run_meta_pipeline --n_draws 500
python -m scripts.publish_pack --meta_dir outputs/runs/meta_pipeline/<timestamp>
```

### Tests (if/when added)
```bash
pytest -q
```
