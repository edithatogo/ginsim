# Decision Log

## 02 March 2026
- Created JAX/XLA-first scaffold and protocol materials (v1.0).
- Added executable scaffolds for Modules D–F and VOI utilities (v1.1).
- Added context-engineering artefacts (assumptions registry, jurisdiction profiles, experiment cards).
