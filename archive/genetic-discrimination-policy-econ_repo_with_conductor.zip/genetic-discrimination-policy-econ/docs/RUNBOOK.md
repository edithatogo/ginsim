# Runbook

## 1) Configure the jurisdiction and policy rules
- Choose a jurisdiction (`australia` or `new_zealand`).
- Use `configs/policies_australia.yaml` or `configs/policies_new_zealand.yaml`.
- Update / validate the matching profile in `context/jurisdiction_profiles/`.

- Create/update a jurisdiction profile in `context/jurisdiction_profiles/`.
- Update `configs/policies.yaml` to match statutory definitions and policy levers.

## 2) Define data schemas
- Fill out `context/data_dictionary_template.md` for each dataset.
- Implement ETL into `data/processed/` (not included in scaffold).

## 3) Fit modules
- Use NumPyro/BlackJAX in `src/inference/` (to be implemented for your data).
- Store posterior draws in `outputs/posterior_samples/` with run manifests.

## 4) Run policy evaluation
- `python -m scripts.run_policy_sweep`
- `python -m scripts.run_voi`

## 5) Record assumptions and decisions
- Update `context/assumptions_registry.yaml` and `context/decision_log.md`.
- Create an experiment card for each major run.
